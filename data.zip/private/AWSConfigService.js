const AWS = require('aws-sdk');
// AWS.config.loadFromPath('./config.json');
AWS.config.update({ "accessKeyId": "AKIAJAQ4NFVIGUYC5HEQ", "secretAccessKey": "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", "region": "us-east-1" });
module.exports = AWS;